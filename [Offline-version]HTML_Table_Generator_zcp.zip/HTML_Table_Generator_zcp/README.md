# LaTeX Table Generator_zcp

## [Tables Generator](http://www.tablesgenerator.com/)



可离线使用的生成LaTeX表格工具。

​																——2019.06

## 在线版用法

网址： <https://chengpengzhao.com/LaTeX_Table_Generator_zcp/>

## 本地版用法

1. clone或download到本地
2. 解压**[Offline-version]LaTeX_Table_Generator_zcp.rar**
3. 双击文件夹里的 **latex_tables.htm**
4. 愉快的制表吧~
